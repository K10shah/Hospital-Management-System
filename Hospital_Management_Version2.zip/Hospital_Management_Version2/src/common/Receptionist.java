package common;

public class Receptionist extends Employee {

	Receptionist(String username, String name)
	{
		this.setName(name);
		this.setUserName(username);
	}
	
	//More functionality to be added in the future
}
